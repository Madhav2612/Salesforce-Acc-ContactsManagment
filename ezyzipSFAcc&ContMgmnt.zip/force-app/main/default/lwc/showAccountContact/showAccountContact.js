import { MessageContext, subscribe, unsubscribe } from 'lightning/messageService';
import { LightningElement, wire ,api} from 'lwc';
import MC1 from '@salesforce/messageChannel/MC1__c';
import getAccountContacts from '@salesforce/apex/AccountClass.getAccountContacts';
import LightningConfirm from 'lightning/confirm';
import { deleteRecord } from 'lightning/uiRecordApi';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';


export default class ShowAccountContact extends LightningElement {


    subscription=null;
    title='Contacts';
    contacts;
    hasContacts;
    isAccountSelected=false;
    isAddContactClicked=false;
    isEditClicked=false;
    @api recordId;
    editableContactId;

    @wire (MessageContext) messageContext;
    accountId;
    accountName;

    connectedCallback()
    {
        this.handleSubscribe();
    }

    disconnectedCallback()
    {
        this.handleUnSubscribe();
    }
    handleSubscribe()
    {
        if(!this.subscription)
        {
            this.subscription=subscribe(this.messageContext,MC1 ,
                (parameter)=> 
                {
                    this.accountId=parameter.accountId;
                    this.accountName=parameter.accountName;
                    this.title=this.accountName+"'s Contacts";
                    this.getContacts();
                }
                );
        }
    }

    async getContacts()
    {
        this.contacts= await getAccountContacts({accountId : this.accountId});
        console.log('My contact List: '+JSON.stringify(this.contacts));
        this.hasContacts=this.contacts.length>0?true:false;
        this.isAccountSelected=true;
    }

    handleUnSubscribe()
    {
        unsubscribe(this.subscription);
        this.subscription=null;

    }

    handleAddContact(event)
    {
        this.isAddContactClicked=true;
    }
    handleAddContactCancel(event)
    {
        this.isAddContactClicked=false;
    }

    handleEdit(event)
    {
        this.isEditClicked=true;
        this. editableContactID=event.target.dataset.contactId;
    }
    handleEditCancel(event)
    {
        this.isEditClicked=false;
    }
    handleSuccess(event)
    {
        this.isAddContactClicked=false;
        this.isEditClicked=false;
        this.getContacts();
    }
    async handleDelete(event)
    {
        this.editableContactID=event.target.dataset.contactId;
        const result = await LightningConfirm.open({
            message: 'Are you sure you want to delete this data?',
            variant: 'headerless',
            label: 'this is the aria-label value',
            // setting theme would have no effect
        });
        if(result)
        {
            await deleteRecord(this.editableContactID);
            this.getContacts();
            this.showToast();
        }

    }
  


showToast() {
    const event = new ShowToastEvent({
        title: 'Deletion Of Contact',
        message:
            'Contact Has Been Deleted Sucesfully, please have a great day ahead',
    });
    this.dispatchEvent(event);
    }
}