import { LightningElement ,api, wire} from 'lwc';
import getAccounts from '@salesforce/apex/AccountClass.getAccounts';
import { MessageContext, publish } from 'lightning/messageService';
import MC1 from '@salesforce/messageChannel/MC1__c';

export default class Accchild2 extends LightningElement {
    @api searchTextChild2;

    @wire (MessageContext) messageContext;

    columns=[
        {label: 'Id', fieldName:'Id'},
        {label: 'Name',fieldName:'Name'},
        {label: 'Actions',fieldName:'Actions', type:'button' , typeAttributes :
        {
            label:'View Contacts',
            value:'view_contacts'
        } 
    }
    ]


    // [] defines array
    // {} defines object

    rows=[
        {Id:'23',Name:'Sergio Marqina',},
        {Id:'30',Name:'Ana Maria',},
        {Id:'33',Name:'Robert De Niro',},
        {Id:'36',Name:'Antonio',}
    ]

    currentId;
    currentName;

    handleRowAction(event)
    {
        if(event.detail.action.value=='view_contacts')
        {
            this.currentId=event.detail.row.Id;
            this.currentName=event.detail.row.Name;
            
            const payload=
            {
                accountId: event.detail.row.Id,
                accountName: event.detail.row.Name
            };

            publish (this.messageContext , MC1 , payload);
        }
        
    }
    @wire(getAccounts , {searchTextClass:'$searchTextChild2'}) accountRecords;

}

